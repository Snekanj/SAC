
let columnCount = 3;
let columns = [];

const board = document.getElementById("board");
const columnInput = document.getElementById("columnInput");
const addBtn = document.getElementById("addColumn");
const removeBtn = document.getElementById("removeColumn");

function updateGrid() {
    board.style.gridTemplateColumns = `repeat(${columnCount}, 1fr)`;
}

function renderColumns() {
    board.innerHTML = "";
    columns.forEach((col, index) => {
        const columnDiv = document.createElement("div");
        columnDiv.className = "column";
        columnDiv.draggable = true;
        columnDiv.style.backgroundColor = col.color;

        columnDiv.innerHTML = `
            <h2>${col.title}</h2>
            <label>Order:</label>
            <input type="number" class="order-input" value="${index}" data-index="${index}">
            <button class="edit-btn" data-index="${index}">Edit</button>
            <div class="edit-panel" style="display:none;">
                <input type="text" class="title-input" placeholder="New title">
                <input type="color" class="color-input">
                <button class="save-btn">Save</button>
            </div>
        `;

        // Drag events
        columnDiv.addEventListener("dragstart", (e) => {
            e.dataTransfer.setData("text/plain", index);
        });

        columnDiv.addEventListener("dragover", (e) => {
            e.preventDefault();
        });

        columnDiv.addEventListener("drop", (e) => {
            e.preventDefault();
            const fromIndex = e.dataTransfer.getData("text/plain");
            const temp = columns[fromIndex];
            columns[fromIndex] = columns[index];
            columns[index] = temp;
            renderColumns();
        });

        board.appendChild(columnDiv);
    });

    addEditEvents();
    addOrderEvents();
}

function addEditEvents() {
    document.querySelectorAll(".edit-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const index = e.target.dataset.index;
            const panel = e.target.nextElementSibling;
            panel.style.display = panel.style.display === "none" ? "block" : "none";
        });
    });

    document.querySelectorAll(".save-btn").forEach((btn, i) => {
        btn.addEventListener("click", () => {
            const columnDiv = btn.closest(".column");
            const titleInput = columnDiv.querySelector(".title-input");
            const colorInput = columnDiv.querySelector(".color-input");

            if (titleInput.value) columns[i].title = titleInput.value;
            if (colorInput.value) columns[i].color = colorInput.value;

            renderColumns();
        });
    });
}

function addOrderEvents() {
    document.querySelectorAll(".order-input").forEach(input => {
        input.addEventListener("change", (e) => {
            const fromIndex = parseInt(e.target.dataset.index);
            const toIndex = parseInt(e.target.value);

            if (toIndex >= 0 && toIndex < columns.length) {
                const moved = columns.splice(fromIndex, 1)[0];
                columns.splice(toIndex, 0, moved);
                renderColumns();
            }
        });
    });
}

function updateColumns() {
    while (columns.length < columnCount) {
        columns.push({ title: "Column " + (columns.length + 1), color: "lightgray" });
    }
    columns = columns.slice(0, columnCount);
    updateGrid();
    renderColumns();
}

columnInput.addEventListener("input", (e) => {
    columnCount = parseInt(e.target.value) || 1;
    updateColumns();
});

addBtn.addEventListener("click", () => {
    columnCount++;
    columnInput.value = columnCount;
    updateColumns();
});

removeBtn.addEventListener("click", () => {
    if (columnCount > 1) {
        columnCount--;
        columnInput.value = columnCount;
        updateColumns();
    }
});

updateColumns();
